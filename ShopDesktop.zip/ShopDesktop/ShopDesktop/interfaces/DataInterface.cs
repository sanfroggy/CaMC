﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShopDesktop.interfaces
{
    static class DataInterface
    {
        public static string tkn = "";
        public static string role = "";
    }
}
